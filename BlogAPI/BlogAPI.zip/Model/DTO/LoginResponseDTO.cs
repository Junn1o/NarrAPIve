﻿namespace BlogAPI.Model.DTO
{
    public class LoginResponseDTO
    {
        public string JwtToken { set; get; }
    }
}
