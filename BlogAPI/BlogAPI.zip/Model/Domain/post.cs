﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace BlogAPI.Model.Domain
{
    public class post
    {
        [Key]
        public Guid post_id { get; set; }
        public string post_title { get; set; }
        public string post_description { get; set; }
        public bool post_status { get; set; }
        public DateTime post_createDate { get; set; }
        public bool post_hidden { get; set; }
        public bool post_type { get; set; }
        public List<post_category_temp> post_category_temp { get; set; }
        public user user { get; set; }
        public List<volume> volume { get; set; }
    }
}
